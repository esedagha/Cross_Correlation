''' Continuum normalisation '''

def normalise_continuum(flux,plot=False):
    medFlux = np.median(flux,axis=2) # Very rough proxy for continuum flux
    for iDet in range(nDet):
        for iObs in range(nObs):
            flux[iDet,iObs,] /= np.median(medFlux[iDet,iObs])
        if plot: plotMatrix(flux[iDet,],wlen[iDet,],ph,'Wavelength (nm)','Orbital phase')
    return flux, medFlux

fFlat, medFlux = normalise_continuum(flux.copy(),plot=True)


''' Telluric detrending '''

def detrend_tellurics(xvec, cube, deg=2, plot=False):
    nDet, nObs, nPix = cube.shape
    tRem = cube.copy()
    for iDet in range(nDet):
        for iPix in range(nPix):
            fit = np.poly1d(np.polyfit(xvec,cube[iDet,:,iPix],deg))(xvec)
            tRem[iDet,:,iPix] = cube[iDet,:,iPix] / fit
        if plot: plotMatrix(tRem[iDet,],wlen[iDet,],ph,'Wavelength (nm)','Orbital phase',stretch=True)
    return tRem

tRem = detrend_tellurics(air,fFlat,deg=2,plot=True)


''' Applying mask and variance normalisation '''
def mask_residuals(cube,thre=2.0):
    nD, nF, nP = cube.shape
    masked = cube.copy() - 1.0
    std = np.std(masked,axis=1)   # It has dimension (nDet, nPix)
    for iD in range(nD):
        mask1 = (std[iD,] > thre * np.median(std[iD,]))
        mask2 = (std[iD,] < 0.2*np.median(std[iD,]))
        mask = mask1 + mask2
        masked[iD,:,mask] = 0.0
        good = mask == False
        for iF in range(nF):
            masked[iD,iF,good] /= std[iD,good]**2
        masked[iD,] *= np.mean(std[iD,good]**2)
    return masked    
    
masked = mask_residuals(tRem)
for iDet in range(nDet): plotMatrix(masked[iDet,],wlen[0,],ph,stretch=True)

''' Faster CC code '''
def xcorr(f,g):
    nx = len(f)
    I = np.ones(nx)
    f -= np.dot(f,I)/nx
    g -= np.dot(g,I)/nx
    R = np.dot(f,g)/nx
    varf = np.dot(f,f)/nx
    varg = np.dot(g,g)/nx
    return R / np.sqrt(varf*varg)

''' CCF on a grid - slower version '''
def get_cc_grid_slow(wMod,fMod,wlen):
    ccf = np.zeros((nDet,nObs,ncc))
    for iDet in range(nDet):
        for irv, rv in enumerate(rvlag):
            beta = rv / 2.998E5
            wMod1 = wMod.copy() * np.sqrt( (1+beta) / (1-beta) )       # Doppler-shifted model wavelengths
            coef_spline = interpolate.splrep(wMod1, fMod, s=0.0)
            intMod = interpolate.splev(wlen[iDet,], coef_spline, der=0)
            for iObs in range(nObs):
                ccf[iDet,iObs,irv] = xcorr_slow(masked[iDet,iObs,], intMod)
    return ccf

''' Shifting and co-adding '''
def get_velocity_map(ccfSum,ccfW,rvel,ph,dphi):
    ccfTot = np.zeros((nKp,nVr))
    for ikp in range(nKp):
        rvPl = rvel + kpVec[ikp] * np.sin(2.0*np.pi*(ph+dphi))
        for iObs in range(nObs):
            outRV = vrest + rvPl[iObs]
            fit = interpolate.interp1d(rvlag, ccfSum[iObs,])
            ccfTot[ikp,] += fit(outRV)# * ccfWeight[iObs]
    return ccfTot

ccfTot = get_velocity_map(ccfSum,ccfWeight,rvel,ph,dphi)
